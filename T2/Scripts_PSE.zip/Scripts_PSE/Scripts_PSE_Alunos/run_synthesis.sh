#!/bin/sh

sed "s/pseaula/${3}/g" script_sources/rc_script_nao_otimizado_best.txt > script_sources/rc_script_nao_otimizado_best2.txt
sed "s/roger/${4}/g" script_sources/rc_script_nao_otimizado_best2.txt > script_sources/rc_script_nao_otimizado_best.tcl

sed "s/pseaula/${3}/g" script_sources/rc_script_nao_otimizado_worst.txt > script_sources/rc_script_nao_otimizado_worst2.txt
sed "s/roger/${4}/g" script_sources/rc_script_nao_otimizado_worst2.txt > script_sources/rc_script_nao_otimizado_worst.tcl

sed "s/pseaula/${3}/g" script_sources/rc_script_otimizado_best.txt > script_sources/rc_script_otimizado_best2.txt
sed "s/roger/${4}/g" script_sources/rc_script_otimizado_best2.txt > script_sources/rc_script_otimizado_best.tcl

sed "s/pseaula/${3}/g" script_sources/rc_script_otimizado_worst.txt > script_sources/rc_script_otimizado_worst2.txt
sed "s/roger/${4}/g" script_sources/rc_script_otimizado_worst2.txt > script_sources/rc_script_otimizado_worst.tcl

mv script_sources/rc_script_nao_otimizado_best.tcl ~/${2}/${1}/${PROJECT_DIR}/trunk/backend/synthesis/work/
mv script_sources/rc_script_nao_otimizado_worst.tcl ~/${2}/${1}/${PROJECT_DIR}/trunk/backend/synthesis/work/
mv script_sources/rc_script_otimizado_best.tcl ~/${2}/${1}/${PROJECT_DIR}/trunk/backend/synthesis/work/
mv script_sources/rc_script_otimizado_worst.tcl ~/${2}/${1}/${PROJECT_DIR}/trunk/backend/synthesis/work/

rm sdf_cmd_file.cmd
sed "s/pseaula/${2}/g" sdf_cmd_file.txt > sdf_cmd_file2.txt
sed "s/jordang/${1}/g" sdf_cmd_file2.txt > sdf_cmd_file3.txt
sed "s/roger/${4}/g" sdf_cmd_file3.txt > sdf_cmd_file.cmd
rm sintese_logica.sh
sed "s/pseaula/${2}/g" sintetizador.txt > sintese_logica.sh
rm coleta_resultados.sh
sed "s/pseaula/${2}/g" coleta_resultados.txt > coleta_resultados.sh

rm script_sources/rc_script_otimizado_best2.txt
rm script_sources/rc_script_otimizado_worst2.txt
rm script_sources/rc_script_nao_otimizado_best2.txt
rm script_sources/rc_script_nao_otimizado_worst2.txt
rm sdf_cmd_file2.txt
rm sdf_cmd_file3.txt
chmod a+rwx *.sh

./sintese_logica.sh ${1} ${5}


