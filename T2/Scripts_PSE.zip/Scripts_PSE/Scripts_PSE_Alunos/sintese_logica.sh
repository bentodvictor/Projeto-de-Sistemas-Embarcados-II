#!/bin/bash

export DESIGNS=$1 ;# put here the name of current design
export PROJECT_DIR=~/tiago/${DESIGNS}
export TECH_DIR=/home/tools/design_kits/ibm180 ;# technology dependent
export HDL_NAME=${DESIGNS}
module add cdn/rc/rc142
module add cdn/incisiv/incisive152

# Entra no diretorio de trabalho
cd ${PROJECT_DIR}/trunk/backend/synthesis/work

# Inicializa a ferramenta e realiza a sintese logica

if [ $2 = 1 ]; then
    rc -64 -gui -logfile rc.log -cmdfile rc.cmd -file rc_script_nao_otimizado_worst.tcl 
fi

if [ $2 = 2 ]; then
    rc -64 -gui -logfile rc.log -cmdfile rc.cmd -file rc_script_nao_otimizado_best.tcl 
fi

if [ $2 = 3 ]; then
    rc -64 -gui -logfile rc.log -cmdfile rc.cmd -file rc_script_otimizado_worst.tcl 
fi

if [ $2 = 4 ]; then
    rc -64 -gui -logfile rc.log -cmdfile rc.cmd -file rc_script_otimizado_best.tcl 
fi

