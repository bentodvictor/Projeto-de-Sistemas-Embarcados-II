#!/bin/sh
chmod a+rwx *.sh
mkdir -p ~/${2}/${1}/trunk/frontend/hdl_temp
mkdir -p ~/${2}/${1}/trunk/frontend/simulation
mkdir -p ~/${2}/${1}/trunk/backend/layout/constraints
mkdir -p ~/${2}/${1}/trunk/backend/layout/deliverables
mkdir -p ~/${2}/${1}/trunk/backend/layout/outputs
mkdir -p ~/${2}/${1}/trunk/backend/layout/reports
mkdir -p ~/${2}/${1}/trunk/backend/layout/scripts
mkdir -p ~/${2}/${1}/trunk/backend/layout/work
mkdir -p ~/${2}/${1}/trunk/backend/synthesis/constraints
mkdir -p ~/${2}/${1}/trunk/backend/synthesis/deliverables
mkdir -p ~/${2}/${1}/trunk/backend/synthesis/reports
mkdir -p ~/${2}/${1}/trunk/backend/synthesis/scripts/common
mkdir -p ~/${2}/${1}/trunk/backend/synthesis/work
mkdir -p ~/${2}/${1}/trunk/verification

cp script_sources/path.tcl ~/${2}/${1}/trunk/backend/synthesis/scripts/common/
cp script_sources/tech.best.tcl ~/${2}/${1}/${PROJECT_DIR}/trunk/backend/synthesis/scripts/common/
cp script_sources/tech.worst.tcl ~/${2}/${1}/${PROJECT_DIR}/trunk/backend/synthesis/scripts/common/
cp script_sources/constraints.sdc ~/${2}/${1}/${PROJECT_DIR}/trunk/backend/synthesis/constraints/

cp *.vhd ~/${2}/${1}/trunk/frontend/
cp *.sh ~/${2}/${1}/trunk/frontend/
cp -r script_sources ~/${2}/${1}/trunk/frontend/
cp -r IBM_verilog ~/${2}/${1}/trunk/frontend/
cp *.txt ~/${2}/${1}/trunk/frontend/

cd ~/${2}/${1}/trunk/frontend/
module add cdn/incisiv/incisive152
