#!/bin/sh
cd ~/tiago/${1}/trunk/frontend
mkdir report_${2}
cd ~/tiago/${1}/trunk/backend/synthesis/deliverables
mv ${1}.v ${1}_${2}.v
mv ${1}.sdf ${1}_${2}.sdf
mv * ~/tiago/${1}/trunk/frontend/report_${2}
cd ~/tiago/${1}/trunk/backend/synthesis/work
mv *.report ~/tiago/${1}/trunk/frontend/report_${2}

