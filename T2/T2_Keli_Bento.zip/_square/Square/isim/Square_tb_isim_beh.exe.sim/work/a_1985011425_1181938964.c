/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x8ef4fb42 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/Windows7Starter/Desktop/_square/Square/Control_Path.vhd";
extern char *IEEE_P_2592010699;
extern char *IEEE_P_3620187407;

unsigned char ieee_p_2592010699_sub_1744673427_503743352(char *, char *, unsigned int , unsigned int );


static void work_a_1985011425_1181938964_p_0(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    unsigned char t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;

LAB0:    xsi_set_current_line(48, ng0);
    t1 = (t0 + 684U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = (t3 == (unsigned char)3);
    if (t4 != 0)
        goto LAB2;

LAB4:    t1 = (t0 + 568U);
    t3 = ieee_p_2592010699_sub_1744673427_503743352(IEEE_P_2592010699, t1, 0U, 0U);
    if (t3 != 0)
        goto LAB5;

LAB6:
LAB3:    t1 = (t0 + 4516);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(49, ng0);
    t1 = (t0 + 2052U);
    t5 = *((char **)t1);
    t1 = (t0 + 4640);
    t6 = (t1 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    memcpy(t9, t5, 3U);
    xsi_driver_first_trans_fast(t1);
    goto LAB3;

LAB5:    xsi_set_current_line(52, ng0);
    t2 = (t0 + 1788U);
    t5 = *((char **)t2);
    t2 = (t0 + 4640);
    t6 = (t2 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    memcpy(t9, t5, 3U);
    xsi_driver_first_trans_fast(t2);
    goto LAB3;

}

static void work_a_1985011425_1181938964_p_1(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    int t4;
    char *t5;
    int t6;
    char *t7;
    int t8;
    char *t9;
    int t10;
    unsigned char t11;
    char *t12;
    unsigned char t13;
    unsigned char t14;
    char *t15;
    unsigned char t16;
    unsigned char t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;

LAB0:    xsi_set_current_line(60, ng0);
    t1 = (t0 + 1696U);
    t2 = *((char **)t1);
    t1 = (t0 + 2052U);
    t3 = *((char **)t1);
    t4 = xsi_mem_cmp(t3, t2, 3U);
    if (t4 == 1)
        goto LAB3;

LAB8:    t1 = (t0 + 2120U);
    t5 = *((char **)t1);
    t6 = xsi_mem_cmp(t5, t2, 3U);
    if (t6 == 1)
        goto LAB4;

LAB9:    t1 = (t0 + 2188U);
    t7 = *((char **)t1);
    t8 = xsi_mem_cmp(t7, t2, 3U);
    if (t8 == 1)
        goto LAB5;

LAB10:    t1 = (t0 + 2256U);
    t9 = *((char **)t1);
    t10 = xsi_mem_cmp(t9, t2, 3U);
    if (t10 == 1)
        goto LAB6;

LAB11:
LAB7:    xsi_set_current_line(86, ng0);
    t1 = (t0 + 684U);
    t2 = *((char **)t1);
    t11 = *((unsigned char *)t2);
    t13 = (t11 == (unsigned char)2);
    if (t13 != 0)
        goto LAB33;

LAB35:    xsi_set_current_line(89, ng0);
    t1 = (t0 + 2052U);
    t2 = *((char **)t1);
    t1 = (t0 + 4676);
    t3 = (t1 + 32U);
    t5 = *((char **)t3);
    t7 = (t5 + 40U);
    t9 = *((char **)t7);
    memcpy(t9, t2, 3U);
    xsi_driver_first_trans_fast(t1);

LAB34:
LAB2:    t1 = (t0 + 4524);
    *((int *)t1) = 1;

LAB1:    return;
LAB3:    xsi_set_current_line(62, ng0);
    t1 = (t0 + 776U);
    t12 = *((char **)t1);
    t13 = *((unsigned char *)t12);
    t14 = (t13 == (unsigned char)3);
    if (t14 == 1)
        goto LAB16;

LAB17:    t11 = (unsigned char)0;

LAB18:    if (t11 != 0)
        goto LAB13;

LAB15:    xsi_set_current_line(65, ng0);
    t1 = (t0 + 2052U);
    t2 = *((char **)t1);
    t1 = (t0 + 4676);
    t3 = (t1 + 32U);
    t5 = *((char **)t3);
    t7 = (t5 + 40U);
    t9 = *((char **)t7);
    memcpy(t9, t2, 3U);
    xsi_driver_first_trans_fast(t1);

LAB14:    goto LAB2;

LAB4:    xsi_set_current_line(69, ng0);
    t1 = (t0 + 684U);
    t2 = *((char **)t1);
    t11 = *((unsigned char *)t2);
    t13 = (t11 == (unsigned char)2);
    if (t13 != 0)
        goto LAB19;

LAB21:    xsi_set_current_line(72, ng0);
    t1 = (t0 + 2052U);
    t2 = *((char **)t1);
    t1 = (t0 + 4676);
    t3 = (t1 + 32U);
    t5 = *((char **)t3);
    t7 = (t5 + 40U);
    t9 = *((char **)t7);
    memcpy(t9, t2, 3U);
    xsi_driver_first_trans_fast(t1);

LAB20:    goto LAB2;

LAB5:    xsi_set_current_line(75, ng0);
    t1 = (t0 + 684U);
    t2 = *((char **)t1);
    t13 = *((unsigned char *)t2);
    t14 = (t13 == (unsigned char)2);
    if (t14 == 1)
        goto LAB25;

LAB26:    t11 = (unsigned char)0;

LAB27:    if (t11 != 0)
        goto LAB22;

LAB24:    t1 = (t0 + 684U);
    t2 = *((char **)t1);
    t13 = *((unsigned char *)t2);
    t14 = (t13 == (unsigned char)2);
    if (t14 == 1)
        goto LAB30;

LAB31:    t11 = (unsigned char)0;

LAB32:    if (t11 != 0)
        goto LAB28;

LAB29:    xsi_set_current_line(80, ng0);
    t1 = (t0 + 2052U);
    t2 = *((char **)t1);
    t1 = (t0 + 4676);
    t3 = (t1 + 32U);
    t5 = *((char **)t3);
    t7 = (t5 + 40U);
    t9 = *((char **)t7);
    memcpy(t9, t2, 3U);
    xsi_driver_first_trans_fast(t1);

LAB23:    goto LAB2;

LAB6:    xsi_set_current_line(83, ng0);
    t1 = (t0 + 2052U);
    t2 = *((char **)t1);
    t1 = (t0 + 4676);
    t3 = (t1 + 32U);
    t5 = *((char **)t3);
    t7 = (t5 + 40U);
    t9 = *((char **)t7);
    memcpy(t9, t2, 3U);
    xsi_driver_first_trans_fast(t1);
    goto LAB2;

LAB12:;
LAB13:    xsi_set_current_line(63, ng0);
    t1 = (t0 + 2120U);
    t18 = *((char **)t1);
    t1 = (t0 + 4676);
    t19 = (t1 + 32U);
    t20 = *((char **)t19);
    t21 = (t20 + 40U);
    t22 = *((char **)t21);
    memcpy(t22, t18, 3U);
    xsi_driver_first_trans_fast(t1);
    goto LAB14;

LAB16:    t1 = (t0 + 684U);
    t15 = *((char **)t1);
    t16 = *((unsigned char *)t15);
    t17 = (t16 == (unsigned char)2);
    t11 = t17;
    goto LAB18;

LAB19:    xsi_set_current_line(70, ng0);
    t1 = (t0 + 2188U);
    t3 = *((char **)t1);
    t1 = (t0 + 4676);
    t5 = (t1 + 32U);
    t7 = *((char **)t5);
    t9 = (t7 + 40U);
    t12 = *((char **)t9);
    memcpy(t12, t3, 3U);
    xsi_driver_first_trans_fast(t1);
    goto LAB20;

LAB22:    xsi_set_current_line(76, ng0);
    t1 = (t0 + 2256U);
    t5 = *((char **)t1);
    t1 = (t0 + 4676);
    t7 = (t1 + 32U);
    t9 = *((char **)t7);
    t12 = (t9 + 40U);
    t15 = *((char **)t12);
    memcpy(t15, t5, 3U);
    xsi_driver_first_trans_fast(t1);
    goto LAB23;

LAB25:    t1 = (t0 + 868U);
    t3 = *((char **)t1);
    t16 = *((unsigned char *)t3);
    t17 = (t16 == (unsigned char)3);
    t11 = t17;
    goto LAB27;

LAB28:    xsi_set_current_line(78, ng0);
    t1 = (t0 + 2324U);
    t5 = *((char **)t1);
    t1 = (t0 + 4676);
    t7 = (t1 + 32U);
    t9 = *((char **)t7);
    t12 = (t9 + 40U);
    t15 = *((char **)t12);
    memcpy(t15, t5, 3U);
    xsi_driver_first_trans_fast(t1);
    goto LAB23;

LAB30:    t1 = (t0 + 868U);
    t3 = *((char **)t1);
    t16 = *((unsigned char *)t3);
    t17 = (t16 == (unsigned char)2);
    t11 = t17;
    goto LAB32;

LAB33:    xsi_set_current_line(87, ng0);
    t1 = (t0 + 2120U);
    t3 = *((char **)t1);
    t1 = (t0 + 4676);
    t5 = (t1 + 32U);
    t7 = *((char **)t5);
    t9 = (t7 + 40U);
    t12 = *((char **)t9);
    memcpy(t12, t3, 3U);
    xsi_driver_first_trans_fast(t1);
    goto LAB34;

}

static void work_a_1985011425_1181938964_p_2(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;

LAB0:    xsi_set_current_line(97, ng0);

LAB3:    t1 = (t0 + 1696U);
    t2 = *((char **)t1);
    t1 = (t0 + 4712);
    t3 = (t1 + 32U);
    t4 = *((char **)t3);
    t5 = (t4 + 40U);
    t6 = *((char **)t5);
    memcpy(t6, t2, 3U);
    xsi_driver_first_trans_fast(t1);

LAB2:    t7 = (t0 + 4532);
    *((int *)t7) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_1985011425_1181938964_p_3(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;

LAB0:    xsi_set_current_line(98, ng0);

LAB3:    t1 = (t0 + 1880U);
    t2 = *((char **)t1);
    t1 = (t0 + 4748);
    t3 = (t1 + 32U);
    t4 = *((char **)t3);
    t5 = (t4 + 40U);
    t6 = *((char **)t5);
    memcpy(t6, t2, 3U);
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t7 = (t0 + 4540);
    *((int *)t7) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_1985011425_1181938964_p_4(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    unsigned char t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;

LAB0:    xsi_set_current_line(101, ng0);
    t1 = (t0 + 1696U);
    t2 = *((char **)t1);
    t1 = (t0 + 1700U);
    t3 = *((char **)t1);
    t4 = (t0 + 2052U);
    t5 = *((char **)t4);
    t4 = (t0 + 2056);
    t4 = *((char **)t4);
    t6 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t2, t3, t5, t4);
    if (t6 != 0)
        goto LAB3;

LAB4:
LAB5:    t12 = (t0 + 4784);
    t13 = (t12 + 32U);
    t14 = *((char **)t13);
    t15 = (t14 + 40U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t12);

LAB2:    t17 = (t0 + 4548);
    *((int *)t17) = 1;

LAB1:    return;
LAB3:    t7 = (t0 + 4784);
    t8 = (t7 + 32U);
    t9 = *((char **)t8);
    t10 = (t9 + 40U);
    t11 = *((char **)t10);
    *((unsigned char *)t11) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t7);
    goto LAB2;

LAB6:    goto LAB2;

}

static void work_a_1985011425_1181938964_p_5(char *t0)
{
    unsigned char t1;
    unsigned char t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned char t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    unsigned char t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    unsigned char t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    char *t29;
    char *t30;
    char *t31;

LAB0:    xsi_set_current_line(102, ng0);
    t3 = (t0 + 1696U);
    t4 = *((char **)t3);
    t3 = (t0 + 1700U);
    t5 = *((char **)t3);
    t6 = (t0 + 2052U);
    t7 = *((char **)t6);
    t6 = (t0 + 2056);
    t6 = *((char **)t6);
    t8 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t4, t5, t7, t6);
    if (t8 == 1)
        goto LAB8;

LAB9:    t9 = (t0 + 1696U);
    t10 = *((char **)t9);
    t9 = (t0 + 1700U);
    t11 = *((char **)t9);
    t12 = (t0 + 2256U);
    t13 = *((char **)t12);
    t12 = (t0 + 2260);
    t12 = *((char **)t12);
    t14 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t10, t11, t13, t12);
    t2 = t14;

LAB10:    if (t2 == 1)
        goto LAB5;

LAB6:    t15 = (t0 + 1696U);
    t16 = *((char **)t15);
    t15 = (t0 + 1700U);
    t17 = *((char **)t15);
    t18 = (t0 + 2324U);
    t19 = *((char **)t18);
    t18 = (t0 + 2328);
    t18 = *((char **)t18);
    t20 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t16, t17, t19, t18);
    t1 = t20;

LAB7:    if (t1 != 0)
        goto LAB3;

LAB4:
LAB11:    t26 = (t0 + 4820);
    t27 = (t26 + 32U);
    t28 = *((char **)t27);
    t29 = (t28 + 40U);
    t30 = *((char **)t29);
    *((unsigned char *)t30) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t26);

LAB2:    t31 = (t0 + 4556);
    *((int *)t31) = 1;

LAB1:    return;
LAB3:    t21 = (t0 + 4820);
    t22 = (t21 + 32U);
    t23 = *((char **)t22);
    t24 = (t23 + 40U);
    t25 = *((char **)t24);
    *((unsigned char *)t25) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t21);
    goto LAB2;

LAB5:    t1 = (unsigned char)1;
    goto LAB7;

LAB8:    t2 = (unsigned char)1;
    goto LAB10;

LAB12:    goto LAB2;

}

static void work_a_1985011425_1181938964_p_6(char *t0)
{
    unsigned char t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    unsigned char t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    unsigned char t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;

LAB0:    xsi_set_current_line(103, ng0);
    t2 = (t0 + 1696U);
    t3 = *((char **)t2);
    t2 = (t0 + 1700U);
    t4 = *((char **)t2);
    t5 = (t0 + 2052U);
    t6 = *((char **)t5);
    t5 = (t0 + 2056);
    t5 = *((char **)t5);
    t7 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t3, t4, t6, t5);
    if (t7 == 1)
        goto LAB5;

LAB6:    t8 = (t0 + 1696U);
    t9 = *((char **)t8);
    t8 = (t0 + 1700U);
    t10 = *((char **)t8);
    t11 = (t0 + 2188U);
    t12 = *((char **)t11);
    t11 = (t0 + 2192);
    t11 = *((char **)t11);
    t13 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t9, t10, t12, t11);
    t1 = t13;

LAB7:    if (t1 != 0)
        goto LAB3;

LAB4:
LAB8:    t19 = (t0 + 4856);
    t20 = (t19 + 32U);
    t21 = *((char **)t20);
    t22 = (t21 + 40U);
    t23 = *((char **)t22);
    *((unsigned char *)t23) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t19);

LAB2:    t24 = (t0 + 4564);
    *((int *)t24) = 1;

LAB1:    return;
LAB3:    t14 = (t0 + 4856);
    t15 = (t14 + 32U);
    t16 = *((char **)t15);
    t17 = (t16 + 40U);
    t18 = *((char **)t17);
    *((unsigned char *)t18) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t14);
    goto LAB2;

LAB5:    t1 = (unsigned char)1;
    goto LAB7;

LAB9:    goto LAB2;

}

static void work_a_1985011425_1181938964_p_7(char *t0)
{
    unsigned char t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    unsigned char t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    unsigned char t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;

LAB0:    xsi_set_current_line(104, ng0);
    t2 = (t0 + 1696U);
    t3 = *((char **)t2);
    t2 = (t0 + 1700U);
    t4 = *((char **)t2);
    t5 = (t0 + 2052U);
    t6 = *((char **)t5);
    t5 = (t0 + 2056);
    t5 = *((char **)t5);
    t7 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t3, t4, t6, t5);
    if (t7 == 1)
        goto LAB5;

LAB6:    t8 = (t0 + 1696U);
    t9 = *((char **)t8);
    t8 = (t0 + 1700U);
    t10 = *((char **)t8);
    t11 = (t0 + 2120U);
    t12 = *((char **)t11);
    t11 = (t0 + 2124);
    t11 = *((char **)t11);
    t13 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t9, t10, t12, t11);
    t1 = t13;

LAB7:    if (t1 != 0)
        goto LAB3;

LAB4:
LAB8:    t19 = (t0 + 4892);
    t20 = (t19 + 32U);
    t21 = *((char **)t20);
    t22 = (t21 + 40U);
    t23 = *((char **)t22);
    *((unsigned char *)t23) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t19);

LAB2:    t24 = (t0 + 4572);
    *((int *)t24) = 1;

LAB1:    return;
LAB3:    t14 = (t0 + 4892);
    t15 = (t14 + 32U);
    t16 = *((char **)t15);
    t17 = (t16 + 40U);
    t18 = *((char **)t17);
    *((unsigned char *)t18) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t14);
    goto LAB2;

LAB5:    t1 = (unsigned char)1;
    goto LAB7;

LAB9:    goto LAB2;

}

static void work_a_1985011425_1181938964_p_8(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    unsigned char t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    unsigned char t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    unsigned char t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    unsigned char t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    char *t29;
    char *t30;
    char *t31;
    char *t32;
    char *t33;
    char *t34;
    char *t35;

LAB0:    xsi_set_current_line(105, ng0);
    t1 = (t0 + 1696U);
    t2 = *((char **)t1);
    t1 = (t0 + 1700U);
    t3 = *((char **)t1);
    t4 = (t0 + 2120U);
    t5 = *((char **)t4);
    t4 = (t0 + 2124);
    t4 = *((char **)t4);
    t6 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t2, t3, t5, t4);
    if (t6 != 0)
        goto LAB3;

LAB4:    t13 = (t0 + 1696U);
    t14 = *((char **)t13);
    t13 = (t0 + 1700U);
    t15 = *((char **)t13);
    t16 = (t0 + 2052U);
    t17 = *((char **)t16);
    t16 = (t0 + 2056);
    t16 = *((char **)t16);
    t18 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t14, t15, t17, t16);
    if (t18 == 1)
        goto LAB7;

LAB8:    t19 = (t0 + 1696U);
    t20 = *((char **)t19);
    t19 = (t0 + 1700U);
    t21 = *((char **)t19);
    t22 = (t0 + 2188U);
    t23 = *((char **)t22);
    t22 = (t0 + 2192);
    t22 = *((char **)t22);
    t24 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t20, t21, t23, t22);
    t12 = t24;

LAB9:    if (t12 != 0)
        goto LAB5;

LAB6:
LAB10:    t30 = (t0 + 4928);
    t31 = (t30 + 32U);
    t32 = *((char **)t31);
    t33 = (t32 + 40U);
    t34 = *((char **)t33);
    *((unsigned char *)t34) = (unsigned char)8;
    xsi_driver_first_trans_fast_port(t30);

LAB2:    t35 = (t0 + 4580);
    *((int *)t35) = 1;

LAB1:    return;
LAB3:    t7 = (t0 + 4928);
    t8 = (t7 + 32U);
    t9 = *((char **)t8);
    t10 = (t9 + 40U);
    t11 = *((char **)t10);
    *((unsigned char *)t11) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t7);
    goto LAB2;

LAB5:    t25 = (t0 + 4928);
    t26 = (t25 + 32U);
    t27 = *((char **)t26);
    t28 = (t27 + 40U);
    t29 = *((char **)t28);
    *((unsigned char *)t29) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t25);
    goto LAB2;

LAB7:    t12 = (unsigned char)1;
    goto LAB9;

LAB11:    goto LAB2;

}

static void work_a_1985011425_1181938964_p_9(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    unsigned char t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    unsigned char t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    unsigned char t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    unsigned char t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    char *t29;
    char *t30;
    char *t31;
    char *t32;
    char *t33;
    char *t34;
    char *t35;

LAB0:    xsi_set_current_line(108, ng0);
    t1 = (t0 + 1696U);
    t2 = *((char **)t1);
    t1 = (t0 + 1700U);
    t3 = *((char **)t1);
    t4 = (t0 + 2188U);
    t5 = *((char **)t4);
    t4 = (t0 + 2192);
    t4 = *((char **)t4);
    t6 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t2, t3, t5, t4);
    if (t6 != 0)
        goto LAB3;

LAB4:    t13 = (t0 + 1696U);
    t14 = *((char **)t13);
    t13 = (t0 + 1700U);
    t15 = *((char **)t13);
    t16 = (t0 + 2052U);
    t17 = *((char **)t16);
    t16 = (t0 + 2056);
    t16 = *((char **)t16);
    t18 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t14, t15, t17, t16);
    if (t18 == 1)
        goto LAB7;

LAB8:    t19 = (t0 + 1696U);
    t20 = *((char **)t19);
    t19 = (t0 + 1700U);
    t21 = *((char **)t19);
    t22 = (t0 + 2120U);
    t23 = *((char **)t22);
    t22 = (t0 + 2124);
    t22 = *((char **)t22);
    t24 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t20, t21, t23, t22);
    t12 = t24;

LAB9:    if (t12 != 0)
        goto LAB5;

LAB6:
LAB10:    t30 = (t0 + 4964);
    t31 = (t30 + 32U);
    t32 = *((char **)t31);
    t33 = (t32 + 40U);
    t34 = *((char **)t33);
    *((unsigned char *)t34) = (unsigned char)8;
    xsi_driver_first_trans_fast_port(t30);

LAB2:    t35 = (t0 + 4588);
    *((int *)t35) = 1;

LAB1:    return;
LAB3:    t7 = (t0 + 4964);
    t8 = (t7 + 32U);
    t9 = *((char **)t8);
    t10 = (t9 + 40U);
    t11 = *((char **)t10);
    *((unsigned char *)t11) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t7);
    goto LAB2;

LAB5:    t25 = (t0 + 4964);
    t26 = (t25 + 32U);
    t27 = *((char **)t26);
    t28 = (t27 + 40U);
    t29 = *((char **)t28);
    *((unsigned char *)t29) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t25);
    goto LAB2;

LAB7:    t12 = (unsigned char)1;
    goto LAB9;

LAB11:    goto LAB2;

}

static void work_a_1985011425_1181938964_p_10(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    unsigned char t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    unsigned char t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;

LAB0:    xsi_set_current_line(111, ng0);
    t1 = (t0 + 1696U);
    t2 = *((char **)t1);
    t1 = (t0 + 1700U);
    t3 = *((char **)t1);
    t4 = (t0 + 2188U);
    t5 = *((char **)t4);
    t4 = (t0 + 2192);
    t4 = *((char **)t4);
    t6 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t2, t3, t5, t4);
    if (t6 != 0)
        goto LAB3;

LAB4:    t12 = (t0 + 1696U);
    t13 = *((char **)t12);
    t12 = (t0 + 1700U);
    t14 = *((char **)t12);
    t15 = (t0 + 2120U);
    t16 = *((char **)t15);
    t15 = (t0 + 2124);
    t15 = *((char **)t15);
    t17 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t13, t14, t16, t15);
    if (t17 != 0)
        goto LAB5;

LAB6:
LAB7:    t23 = (t0 + 5000);
    t24 = (t23 + 32U);
    t25 = *((char **)t24);
    t26 = (t25 + 40U);
    t27 = *((char **)t26);
    *((unsigned char *)t27) = (unsigned char)8;
    xsi_driver_first_trans_fast_port(t23);

LAB2:    t28 = (t0 + 4596);
    *((int *)t28) = 1;

LAB1:    return;
LAB3:    t7 = (t0 + 5000);
    t8 = (t7 + 32U);
    t9 = *((char **)t8);
    t10 = (t9 + 40U);
    t11 = *((char **)t10);
    *((unsigned char *)t11) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t7);
    goto LAB2;

LAB5:    t18 = (t0 + 5000);
    t19 = (t18 + 32U);
    t20 = *((char **)t19);
    t21 = (t20 + 40U);
    t22 = *((char **)t21);
    *((unsigned char *)t22) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t18);
    goto LAB2;

LAB8:    goto LAB2;

}


void ieee_p_2592010699_sub_3130575329_503743352();

extern void work_a_1985011425_1181938964_init()
{
	static char *pe[] = {(void *)work_a_1985011425_1181938964_p_0,(void *)work_a_1985011425_1181938964_p_1,(void *)work_a_1985011425_1181938964_p_2,(void *)work_a_1985011425_1181938964_p_3,(void *)work_a_1985011425_1181938964_p_4,(void *)work_a_1985011425_1181938964_p_5,(void *)work_a_1985011425_1181938964_p_6,(void *)work_a_1985011425_1181938964_p_7,(void *)work_a_1985011425_1181938964_p_8,(void *)work_a_1985011425_1181938964_p_9,(void *)work_a_1985011425_1181938964_p_10};
	xsi_register_didat("work_a_1985011425_1181938964", "isim/Square_tb_isim_beh.exe.sim/work/a_1985011425_1181938964.didat");
	xsi_register_executes(pe);
	xsi_register_resolution_function(1, 2, (void *)ieee_p_2592010699_sub_3130575329_503743352, 4);
}
